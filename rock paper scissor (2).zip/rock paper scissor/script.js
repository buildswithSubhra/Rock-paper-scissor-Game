// Register Service Worker for PWA functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
                console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Game elements
    const playerScoreEl = document.getElementById('player-score');
    const computerScoreEl = document.getElementById('computer-score');
    const playerChoiceIcon = document.getElementById('player-choice-icon');
    const computerChoiceIcon = document.getElementById('computer-choice-icon');
    const playerChoiceText = document.getElementById('player-choice-text');
    const computerChoiceText = document.getElementById('computer-choice-text');
    const resultMessage = document.getElementById('result-message');
    const resetButton = document.getElementById('reset');
    
    // Choice buttons
    const rockBtn = document.getElementById('rock');
    const paperBtn = document.getElementById('paper');
    const scissorsBtn = document.getElementById('scissors');
    
    // Game state
    let playerScore = 0;
    let computerScore = 0;
    let gameOver = false;
    
    // Icon mapping
    const choiceIcons = {
        'rock': '<i class="fas fa-hand-rock"></i>',
        'paper': '<i class="fas fa-hand-paper"></i>',
        'scissors': '<i class="fas fa-hand-scissors"></i>'
    };
    
    // Event listeners for player choices
    rockBtn.addEventListener('click', () => playRound('rock'));
    paperBtn.addEventListener('click', () => playRound('paper'));
    scissorsBtn.addEventListener('click', () => playRound('scissors'));
    resetButton.addEventListener('click', resetGame);
    
    // Main game function
    function playRound(playerChoice) {
        if (gameOver) return;
        
        // Computer makes a random choice
        const choices = ['rock', 'paper', 'scissors'];
        const computerChoice = choices[Math.floor(Math.random() * 3)];
        
        // Update choices display
        playerChoiceIcon.innerHTML = choiceIcons[playerChoice];
        computerChoiceIcon.innerHTML = choiceIcons[computerChoice];
        playerChoiceText.textContent = playerChoice;
        computerChoiceText.textContent = computerChoice;
        
        // Determine winner
        let result;
        if (playerChoice === computerChoice) {
            result = 'draw';
        } else if (
            (playerChoice === 'rock' && computerChoice === 'scissors') ||
            (playerChoice === 'paper' && computerChoice === 'rock') ||
            (playerChoice === 'scissors' && computerChoice === 'paper')
        ) {
            result = 'win';
            playerScore++;
        } else {
            result = 'lose';
            computerScore++;
        }
        
        // Update UI
        updateScore();
        showResult(result, playerChoice, computerChoice);
        
        // Check for game over
        if (playerScore === 5 || computerScore === 5) {
            gameOver = true;
            setTimeout(() => {
                if (playerScore === 5) {
                    showResult('game-win');
                    createConfetti();
                } else {
                    showResult('game-lose');
                }
            }, 1000);
        }
    }
    
    // Update score display
    function updateScore() {
        playerScoreEl.textContent = playerScore;
        computerScoreEl.textContent = computerScore;
    }
    
    // Show round result
    function showResult(result, playerChoice, computerChoice) {
        resultMessage.classList.remove('win', 'lose', 'draw');
        
        switch(result) {
            case 'win':
                resultMessage.textContent = `You win! ${capitalizeFirstLetter(playerChoice)} beats ${computerChoice}`;
                resultMessage.classList.add('win');
                break;
            case 'lose':
                resultMessage.textContent = `You lose! ${capitalizeFirstLetter(computerChoice)} beats ${playerChoice}`;
                resultMessage.classList.add('lose');
                break;
            case 'draw':
                resultMessage.textContent = "It's a draw!";
                resultMessage.classList.add('draw');
                break;
            case 'game-win':
                resultMessage.textContent = "Congratulations! You won the game!";
                resultMessage.classList.add('win');
                break;
            case 'game-lose':
                resultMessage.textContent = "Game over! The computer won this time.";
                resultMessage.classList.add('lose');
                break;
        }
        
        resultMessage.classList.add('fade-in');
        setTimeout(() => {
            resultMessage.classList.remove('fade-in');
        }, 500);
    }
    
    // Reset game function
    function resetGame() {
        playerScore = 0;
        computerScore = 0;
        gameOver = false;
        updateScore();
        
        playerChoiceIcon.innerHTML = '❓';
        computerChoiceIcon.innerHTML = '❓';
        playerChoiceText.textContent = '-';
        computerChoiceText.textContent = '-';
        
        resultMessage.textContent = "Make your move!";
        resultMessage.classList.remove('win', 'lose', 'draw');
    }
    
    // Helper function to capitalize first letter
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    // Create confetti effect for win
    function createConfetti() {
        const colors = ['#f94144', '#f3722c', '#f8961e', '#f9c74f', '#90be6d', '#43aa8b', '#577590'];
        
        for (let i = 0; i < 50; i++) {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            confetti.style.left = Math.random() * 100 + 'vw';
            confetti.style.top = -20 + 'px';
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.width = (Math.random() * 10 + 5) + 'px';
            confetti.style.height = (Math.random() * 10 + 5) + 'px';
            confetti.style.transform = `rotate(${Math.random() * 360}deg)`;
            document.body.appendChild(confetti);
            
            // Animate confetti
            const animation = confetti.animate([
                { top: '-20px', transform: 'rotate(0deg)' },
                { top: '100vh', transform: `rotate(${Math.random() * 720}deg)` }
            ], {
                duration: Math.random() * 2000 + 2000,
                easing: 'cubic-bezier(0.1, 0.8, 0.3, 1)'
            });
            
            // Remove confetti after animation
            animation.onfinish = () => {
                confetti.remove();
            };
        }
    }
});

# Rock Paper Scissors Game

A modern, responsive web-based Rock Paper Scissors game built with HTML, CSS, and JavaScript.

## Features

- 🎮 Classic Rock Paper Scissors gameplay
- 🎯 First to 5 wins game mode
- 📱 Fully responsive design
- 🎨 Beautiful gradient backgrounds and animations
- 🎉 Confetti celebration effect on win
- 🔄 Reset game functionality

## How to Play

1. Click on Rock, Paper, or Scissors to make your choice
2. The computer will randomly select its choice
3. The winner of each round is determined by the classic rules:
   - Rock beats Scissors
   - Paper beats Rock  
   - Scissors beats Paper
4. First player to reach 5 points wins the game
5. Click "Reset Game" to start over

## Hosting Instructions

This project is fully optimized for hosting on modern platforms with PWA capabilities, SEO optimization, and deployment configurations.

### Quick Deployment Options:

#### GitHub Pages (Recommended)
1. Create a new repository on GitHub
2. Upload all files to the repository
3. Go to repository Settings → Pages
4. Select main branch as source
5. Enable GitHub Actions for automatic deployment
6. Your site will be available at `https://username.github.io/repository-name`

#### Netlify
1. Drag and drop the project folder to Netlify dashboard
2. Or connect your GitHub repository for continuous deployment
3. Netlify will automatically detect the `netlify.toml` configuration
4. Your site will be available immediately

#### Vercel
1. Import your GitHub repository to Vercel
2. Vercel will automatically detect the `vercel.json` configuration
3. Your site will be deployed instantly

#### Manual Deployment
Upload all files to any web server (Apache, Nginx, etc.):
- `index.html` - Main HTML file with PWA support
- `styles.css` - CSS styles
- `script.js` - JavaScript game logic with service worker
- `manifest.json` - PWA manifest
- `sw.js` - Service worker for offline functionality
- `404.html` - Custom error page
- `robots.txt` - Search engine optimization
- `sitemap.xml` - SEO sitemap
- `assets/` - Directory for assets (favicon, images, etc.)
- Deployment config files (`netlify.toml`, `vercel.json`)

### PWA Features:
- **Installable**: Can be installed as a mobile app
- **Offline Support**: Works without internet connection
- **Fast Loading**: Service worker caches assets for quick loading
- **Mobile Optimized**: Responsive design with touch-friendly interface

### SEO Optimization:
- Open Graph meta tags for social media sharing
- Twitter card support
- XML sitemap for search engines
- Robots.txt for crawl optimization
- Semantic HTML structure

### Performance Features:
- Asset caching for fast loading
- Responsive design for all devices
- Optimized images and icons
- Minimal external dependencies

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers

## Technologies Used

- HTML5
- CSS3 (Flexbox, Grid, Animations)
- Vanilla JavaScript
- Font Awesome Icons

## Customization

You can easily customize the game by modifying:
- Colors in `styles.css`
- Game rules in `script.js`
- Styling and layout

## License

This project is open source and available under the MIT License.
